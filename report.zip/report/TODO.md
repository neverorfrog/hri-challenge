- Social signal processing
  - Audio commands
  - Configuration of the field

- Multimodal interaction
  - Both audio and graphical interface

- Mental Model
  - What happens in case of uncertainty? (blocco slide 5)